import React from 'react';
import ReactDOM from 'react-dom/client';
import './index.css';
import App from './App';

import { legacy_createStore as createStore } from "redux";
import { configureStore } from '@reduxjs/toolkit'
import { combineReducers } from 'redux';
// import { createStore } from 'redux';
import { Provider } from 'react-redux';
import {addMessageReducer} from './reducers/addMessageReducer'
import store from './store/store';

const root = ReactDOM.createRoot(document.getElementById('root'));

// const reducers = combineReducers ({
//   addMessage : addMessageReducer
// });


// const store = createStore(
//   // reducers,
//   addMessageReducer,
//   {},
//   window.__REDUX_DEVTOOLS_EXTENSION__ && window.__REDUX_DEVTOOLS_EXTENSION__()
// );

root.render(
  <Provider store={store}>
    <React.StrictMode>
      <App />
    </React.StrictMode>
  </Provider>
);


