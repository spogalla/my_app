import React from 'react';
import {auth} from '../firebase'

const style = {
  message: `flex items-center shadow-xl m-2 py-2 px-3`, //rounded-tl-full rounded-tr-full
  name: `absolute mt-[-4rem] text-gray-600 text-xs`,
  sent: `bg-[#395dff] text-white float-right col-lg-4 sent`, //rounded-bl-full
  received: `bg-[#e5e5ea] text-black float-left col-lg-4 received`,//rounded-br-full
};

const Message = ({ message }) => { //flex-row-reverse
  const messageClass = message.type === "request" ? `${style.sent}` : `${style.received}`
  // message.uid === auth.currentUser.uid
  // ? `${style.sent}`
  // : `${style.received}`

  return (
    <div>
      <div className={`${style.message} ${messageClass}`}>
        {/* <p className={style.name}>{message.name}</p> */}
        <p>{message.text}</p>
      </div>
    </div>
  );
};

export default Message;
