import React, { useState, useEffect } from 'react';
import {auth, db} from '../firebase'
import {addDoc, collection, serverTimestamp} from 'firebase/firestore'
import axios from 'axios'
import SendIcon from '@mui/icons-material/Send';
import { useDispatch } from 'react-redux';
import {add_message} from '../actions/addMessage';

const style = {
  form: `send-message h-14 w-full max-w-[728px]  flex text-xl absolute bottom-0`,
  input: `message-input w-full text-xl p-3 bg-gray-900 text-white outline-none border-none`,
  button: `send-message-button w-[10%] bg-green-500`,
};

const SendMessage = (props) => {
  const [input, setInput] = useState('');
  const dispatch = useDispatch();
  // const [output, setOutput] = useState('')
  let l = [
    "What brings you to therapy? Could you describe the specific difficulties or concerns you're experiencing?",
    "Are there any significant events or experiences from your past that you believe are relevant to your current difficulties?",
    "Have you had any physical or mental health concerns in the past or currently? Are you taking any medications?",
    "Who are the important people in your life, such as family members, friends, or significant others? How do they support you?",
      ];

  const sendMessage = async (e) => {
    e.preventDefault()
    if (input === '') {
        alert('Please enter a valid message')
        return
    }
    let message = {"type" : "request", "text" : input}
    dispatch(add_message(message));


    // const {uid, displayName} = auth.currentUser
    // await addDoc(collection(db, 'messages'), {
    //     text: input,
    //     name: displayName,
    //     uid,
    //     timestamp: serverTimestamp()
    // })

    // axios.get('http://127.0.0.1:5000/'+input)
    // .then(res => {
    //   addDoc(collection(db, 'messages'), {
    //     text: res.data,
    //     name: displayName,
    //     uid : uid + "mocked",
    //     timestamp: serverTimestamp()
    //   })
    // })

    // props.scroll.current.scrollIntoView({behavior: 'smooth'})
    props.scroll.current.scrollIntoView(false)
    setInput('')
    
  }

  return (
    <form onSubmit={sendMessage} className={style.form}>
      <input
        value={input}
        onChange={(e) => setInput(e.target.value)}
        className={style.input}
        type='text'
        placeholder='Message'
      />
      <button className={style.button} type='submit'>
      <SendIcon color='disabled'/>
      </button>
    </form>
  );
};

export default SendMessage;
