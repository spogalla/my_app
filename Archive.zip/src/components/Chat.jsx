import React, { useState, useEffect, useRef } from 'react';
import Message from './Message';
import SendMessage from './SendMessage';
import { db } from '../firebase';
import { query, collection, orderBy, onSnapshot } from 'firebase/firestore';
import { useDispatch, useSelector } from 'react-redux';
import { add_message } from '../actions/addMessage';

const style = {
  main: `chat flex flex-col p-[10px]`,
};

const Chat = () => {
  const scroll = useRef(null);
  const [curr_index, setcurr_index] = useState(); 
  let message = useSelector(state => state.addMessage.messages);
  const [messages, setMessages] = useState(message);
  const dispatch = useDispatch();
  const [l, setl] = useState([]);
  
  const AskQuestion = (question) => {
    message = {"type" : "response", "text" : question};
    dispatch(add_message(message));
    // messages = useSelector(state => state.addMessage.messages);
    // setMessages(messages);
  }

  useEffect(() => {
    // let messages = [
    //   {"id": 1, "type":"request", "text":"Hello"},
    //   {"id": 2, "type":"response", "text":"Hi Good Morning"}
    // ];
    // let messages = useSelector(state => state.messages);
    // setMessages(messages);
    // const q = query(collection(db, 'messages'), orderBy('timestamp'));
    // const unsubscribe = onSnapshot(q, (querySnapshot) => {
    //   // let messages = [];
    //   querySnapshot.forEach((doc) => {
    //     messages.push({ ...doc.data(), id: doc.id });
    //   });
    //   setMessages(messages);
    // });
    // return () => unsubscribe();
    // let message = useSelector(state => state.addMessage.messages);
    // setMessages(message); 
    if(l.length >0){
      AskQuestion(l.pop()) 
    }
  },[curr_index]);

  useEffect(() => {
    console.log('xyz');
    setl([
      "What brings you to therapy? Could you describe the specific difficulties or concerns you're experiencing?",
      "Are there any significant events or experiences from your past that you believe are relevant to your current difficulties?",
      "Have you had any physical or mental health concerns in the past or currently? Are you taking any medications?",
      "Who are the important people in your life, such as family members, friends, or significant others? How do they support you?",
        ]);

    let question = l.pop();
    setl(l)
    console.log(l);
    AskQuestion(question) 
  }, []);

  useEffect(() => {
    if (scroll.current) {
      scroll.current.scrollIntoView({ behavior: "smooth" });
    }
  }, [messages]);

  return (
    <>
      <main className={style.main}>
        {messages &&
          messages.map((message) => (
            <div ref = {scroll}><Message key={message.id} message={message} /></div>
            // <Message key={message.id} message={message} />
          ))}
      </main>
      {/* Send Message Compoenent */}
      <SendMessage scroll={scroll} />
    </>
  );
};

export default Chat;
