const INITIAL_STATE = {
    messages: [
        {"type":"response", "text":"Hello"},
        {"type":"request", "text":"Hi Good Morning"}
      ],
};


const addMessageReducer = (state = INITIAL_STATE, action) => {
    switch(action.type){
        case 'ADD_MESSAGE':
            state.messages = [...state.messages, action.payload];
            return state;
        default:
            return state;
    }
}

export default addMessageReducer;